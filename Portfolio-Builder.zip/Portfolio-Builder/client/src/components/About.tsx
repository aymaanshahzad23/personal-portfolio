import { portfolioData } from "@/lib/portfolio-data";
import { MapPin } from "lucide-react";

export function About() {
  const { about, personal } = portfolioData;

  return (
    <section id="about" className="py-20 md:py-32 px-6 md:px-8">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-about-heading"
        >
          About
        </h2>

        <div className="grid md:grid-cols-3 gap-12 items-start">
          <div className="md:col-span-1 flex flex-col items-center md:items-start">
            <div
              className="w-48 h-48 md:w-64 md:h-64 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4"
              data-testid="img-profile-placeholder"
            >
              <span className="text-6xl md:text-7xl font-bold text-primary/40">
                {personal.name.charAt(0)}
              </span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span className="text-sm" data-testid="text-location">{personal.location}</span>
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            {about.summary.map((paragraph, index) => (
              <p
                key={index}
                className="text-base md:text-lg leading-relaxed text-foreground/80"
                data-testid={`text-about-paragraph-${index}`}
              >
                {paragraph}
              </p>
            ))}
            <p
              className="text-base md:text-lg leading-relaxed text-muted-foreground italic"
              data-testid="text-about-interests"
            >
              {about.interests}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
