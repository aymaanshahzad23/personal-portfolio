import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { portfolioData } from "@/lib/portfolio-data";
import { TrendingUp, Layers } from "lucide-react";

export function Projects() {
  const { projects } = portfolioData;

  return (
    <section id="projects" className="py-20 md:py-32 px-6 md:px-8">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-projects-heading"
        >
          Projects
        </h2>

        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <Card
              key={project.id}
              className="group transition-transform duration-200 hover:-translate-y-1"
              data-testid={`card-project-${project.id}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Layers className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <CardTitle
                  className="text-xl mt-4"
                  data-testid={`text-project-title-${index}`}
                >
                  {project.title}
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                <p
                  className="text-sm md:text-base text-muted-foreground leading-relaxed"
                  data-testid={`text-project-description-${index}`}
                >
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech) => (
                    <Badge
                      key={tech}
                      variant="secondary"
                      className="text-xs"
                      data-testid={`badge-tech-${project.id}-${tech.toLowerCase().replace(/\s+/g, "-")}`}
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>

                {project.metrics && (
                  <div className="flex items-center gap-2 pt-2 text-sm">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    <span
                      className="text-foreground/80 font-medium"
                      data-testid={`text-project-metrics-${index}`}
                    >
                      {project.metrics}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
