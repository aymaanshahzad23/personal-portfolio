import { Button } from "@/components/ui/button";
import { portfolioData } from "@/lib/portfolio-data";
import { SiLinkedin, SiGithub } from "react-icons/si";
import { Mail, ChevronDown } from "lucide-react";

export function Hero() {
  const { personal } = portfolioData;

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <section className="min-h-screen flex flex-col items-center justify-center pt-16 px-6 md:px-8">
      <div className="max-w-4xl mx-auto text-center">
        <h1
          className="text-5xl md:text-7xl font-bold tracking-tight mb-6"
          data-testid="text-hero-name"
        >
          <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
            {personal.name}
          </span>
        </h1>

        <p
          className="text-lg md:text-xl text-muted-foreground mb-4"
          data-testid="text-hero-title"
        >
          {personal.title}
        </p>

        <p
          className="text-base md:text-lg text-foreground/80 max-w-2xl mx-auto mb-8 leading-relaxed"
          data-testid="text-hero-tagline"
        >
          {personal.tagline}
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-8">
          <Button
            size="lg"
            onClick={() => scrollToSection("#projects")}
            data-testid="button-view-projects"
          >
            View Projects
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={() => scrollToSection("#contact")}
            data-testid="button-contact-me"
          >
            Contact Me
          </Button>
        </div>

        <div className="flex items-center justify-center gap-4">
          <a
            href={personal.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full hover-elevate active-elevate-2 transition-colors"
            data-testid="link-linkedin"
            aria-label="LinkedIn"
          >
            <SiLinkedin className="h-6 w-6" />
          </a>
          <a
            href={personal.github}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 rounded-full hover-elevate active-elevate-2 transition-colors"
            data-testid="link-github"
            aria-label="GitHub"
          >
            <SiGithub className="h-6 w-6" />
          </a>
          <a
            href={`mailto:${personal.email}`}
            className="p-2 rounded-full hover-elevate active-elevate-2 transition-colors"
            data-testid="link-email"
            aria-label="Email"
          >
            <Mail className="h-6 w-6" />
          </a>
        </div>
      </div>

      <button
        onClick={() => scrollToSection("#about")}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce"
        data-testid="button-scroll-down"
        aria-label="Scroll down"
      >
        <ChevronDown className="h-8 w-8 text-muted-foreground" />
      </button>
    </section>
  );
}
