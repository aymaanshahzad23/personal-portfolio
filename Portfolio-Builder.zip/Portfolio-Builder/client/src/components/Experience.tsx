import { portfolioData } from "@/lib/portfolio-data";
import { Briefcase, MapPin, Calendar } from "lucide-react";

export function Experience() {
  const { experience } = portfolioData;

  return (
    <section id="experience" className="py-20 md:py-32 px-6 md:px-8 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-experience-heading"
        >
          Experience
        </h2>

        <div className="relative">
          <div className="absolute left-4 md:left-8 top-0 bottom-0 w-0.5 bg-border" />

          <div className="space-y-8">
            {experience.map((exp, index) => (
              <div
                key={exp.id}
                className="relative pl-12 md:pl-20"
                data-testid={`card-experience-${exp.id}`}
              >
                <div className="absolute left-2 md:left-6 top-1 w-5 h-5 rounded-full bg-primary border-4 border-background" />

                <div className="bg-background rounded-xl p-6 border">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2 mb-3">
                    <div>
                      <h3
                        className="text-xl font-semibold"
                        data-testid={`text-experience-role-${index}`}
                      >
                        {exp.role}
                      </h3>
                      <div className="flex items-center gap-2 text-primary">
                        <Briefcase className="h-4 w-4" />
                        <span
                          className="font-medium"
                          data-testid={`text-experience-company-${index}`}
                        >
                          {exp.company}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col md:items-end gap-1 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3.5 w-3.5" />
                        <span data-testid={`text-experience-duration-${index}`}>
                          {exp.duration}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3.5 w-3.5" />
                        <span data-testid={`text-experience-location-${index}`}>
                          {exp.location}
                        </span>
                      </div>
                    </div>
                  </div>

                  {exp.achievements.length > 0 && (
                    <ul className="space-y-2 mt-4">
                      {exp.achievements.map((achievement, achIndex) => (
                        <li
                          key={achIndex}
                          className="text-sm md:text-base text-foreground/80 flex items-start gap-2"
                          data-testid={`text-experience-achievement-${index}-${achIndex}`}
                        >
                          <span className="text-primary mt-1.5 flex-shrink-0">
                            <svg className="h-1.5 w-1.5 fill-current" viewBox="0 0 6 6">
                              <circle cx="3" cy="3" r="3" />
                            </svg>
                          </span>
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
