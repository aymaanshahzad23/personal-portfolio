import { portfolioData } from "@/lib/portfolio-data";

export function Footer() {
  const { personal } = portfolioData;
  const currentYear = new Date().getFullYear();

  return (
    <footer className="py-8 px-6 md:px-8 border-t">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-sm text-muted-foreground" data-testid="text-footer-copyright">
          {currentYear} {personal.name}. All rights reserved.
        </p>
        <p className="text-sm text-muted-foreground">
          Built with passion
        </p>
      </div>
    </footer>
  );
}
