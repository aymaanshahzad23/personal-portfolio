import { Card, CardContent } from "@/components/ui/card";
import { portfolioData } from "@/lib/portfolio-data";
import { GraduationCap, Calendar } from "lucide-react";

export function Education() {
  const { education } = portfolioData;

  return (
    <section id="education" className="py-20 md:py-32 px-6 md:px-8">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-education-heading"
        >
          Education
        </h2>

        <div className="max-w-3xl mx-auto space-y-6">
          {education.map((edu, index) => (
            <Card
              key={edu.institution}
              data-testid={`card-education-${index}`}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <GraduationCap className="h-6 w-6 text-primary" />
                  </div>

                  <div className="flex-1">
                    <h3
                      className="text-lg font-semibold"
                      data-testid={`text-education-institution-${index}`}
                    >
                      {edu.institution}
                    </h3>
                    <p
                      className="text-foreground/80"
                      data-testid={`text-education-degree-${index}`}
                    >
                      {edu.degree} in {edu.field}
                    </p>
                    <div className="flex items-center gap-1 mt-2 text-sm text-muted-foreground">
                      <Calendar className="h-3.5 w-3.5" />
                      <span data-testid={`text-education-duration-${index}`}>
                        {edu.duration}
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
