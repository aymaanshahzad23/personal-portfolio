import { Badge } from "@/components/ui/badge";
import { portfolioData } from "@/lib/portfolio-data";

export function Skills() {
  const { skills, certifications } = portfolioData;

  return (
    <section id="skills" className="py-20 md:py-32 px-6 md:px-8 bg-card/50">
      <div className="max-w-6xl mx-auto">
        <h2
          className="text-3xl md:text-4xl font-bold mb-12 text-center"
          data-testid="text-skills-heading"
        >
          Skills
        </h2>

        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {Object.entries(skills).map(([category, skillList]) => (
            <div
              key={category}
              className="space-y-4"
              data-testid={`card-skills-${category.toLowerCase().replace(/\s+&\s+/g, "-").replace(/\s+/g, "-")}`}
            >
              <h3 className="text-lg font-semibold text-foreground">
                {category}
              </h3>
              <div className="flex flex-wrap gap-2">
                {skillList.map((skill) => (
                  <Badge
                    key={skill}
                    variant="outline"
                    className="px-4 py-2 text-sm rounded-full"
                    data-testid={`badge-skill-${skill.toLowerCase().replace(/\s+/g, "-")}`}
                  >
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="pt-8 border-t">
          <h3
            className="text-xl font-semibold mb-6 text-center"
            data-testid="text-certifications-heading"
          >
            Certifications
          </h3>
          <div className="flex flex-wrap justify-center gap-3">
            {certifications.map((cert) => (
              <Badge
                key={cert}
                className="px-4 py-2 text-sm"
                data-testid={`badge-cert-${cert.toLowerCase().replace(/[:\s]+/g, "-").slice(0, 30)}`}
              >
                {cert}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
