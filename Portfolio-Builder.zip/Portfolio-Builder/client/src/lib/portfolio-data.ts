export const portfolioData = {
  personal: {
    name: "Aymaan Shahzad",
    title: "IIT Bombay '26 | Building in Stealth | Incoming Senior Associate at Meesho",
    tagline: "I solve problems end-to-end. From understanding users to running analyses, building flows, fixing bottlenecks, and driving measurable impact.",
    email: "aymaanshahzad23@gmail.com",
    phone: "+91 7869723885",
    location: "Mumbai, Maharashtra, India",
    linkedin: "https://www.linkedin.com/in/aymaanshahzad23",
    github: "https://github.com/aymaanshahzad23",
  },

  about: {
    summary: [
      "I'm a B.Tech. undergrad at IIT Bombay, Class of 2026, with a deep curiosity for technology, energy systems, and the mechanics of building and scaling products.",
      "My journey across venture capital, founding teams, consumer operations, and strategy roles has shaped into one simple pattern: I like solving problems end-to-end. Understanding users, running analyses, building flows, fixing bottlenecks, and seeing impact play out.",
      "I've represented student groups and led teams on campus, which taught me how much execution, communication, and people matter in getting anything off the ground. Those experiences made me comfortable with fast-moving, ambiguous environments where you're expected to figure things out as you go.",
    ],
    interests: "Beyond work, I love field sports (especially shotput) and unwind by playing guitar or experimenting with music production.",
  },

  experience: [
    {
      id: "stealth",
      company: "Stealth Startup",
      role: "Founder",
      duration: "July 2025 - Present",
      location: "Mumbai, India",
      achievements: [],
    },
    {
      id: "dsse",
      company: "Desai Sethi School of Entrepreneurship, IIT Bombay",
      role: "Entrepreneur in Residence",
      duration: "April 2025 - November 2025",
      location: "Mumbai, India",
      achievements: [
        "Integrated 3 cab service APIs and automated core workflows using LLM-powered pipelines to accelerate MVP development",
        "Secured INR 500K pre-incubation grant for research, product development, and early-stage pilots",
        "Conducted 50+ user interviews and persona studies to refine user journeys and shape MVP",
      ],
    },
    {
      id: "unsw",
      company: "UNSW Business School",
      role: "Research Intern",
      duration: "August 2025 - October 2025",
      location: "Sydney, Australia",
      achievements: [],
    },
    {
      id: "frost",
      company: "Frost & Sullivan",
      role: "Growth Advisory",
      duration: "June 2025 - August 2025",
      location: "Remote",
      achievements: [
        "Quantified $28M whitespace opportunity in therapeutic device market by mapping 110+ competitor product architectures",
        "Built 11-step value chain model improving willingness-to-pay quantification by 35%",
        "Reduced delivery timeline by 120+ man-hours across 6 medical device systems",
      ],
    },
    {
      id: "mcaffeine",
      company: "mCaffeine",
      role: "CEO's Office - Strategy",
      duration: "May 2025 - July 2025",
      location: "Mumbai, India",
      achievements: [
        "Raised prepaid order adoption from 26% to 39%, improving cash flow stability by 2+ weeks",
        "Improved inventory turns from 2.8x to 4.2x, reducing excess stock write-offs by ₹40+ Cr",
        "Reduced average delivery time from 3.8 to 2.6 days across 120K+ service lines, saving ₹175K in logistics",
      ],
    },
    {
      id: "iitb-placement",
      company: "Placement Office, IIT Bombay",
      role: "Institute Internship Coordinator",
      duration: "June 2024 - June 2025",
      location: "Mumbai, India",
      achievements: [
        "Awarded Certificate of Excellence by Professor-in-Charge",
        "Led initiative resulting in 8.1% increase in selection rate YoY and 63% increase in tier-1 placements",
        "Managed 50+ recruiting partners and coordinated 800+ interview slots",
      ],
    },
    {
      id: "neroex",
      company: "Neroex",
      role: "Founder's Office",
      duration: "December 2024 - January 2025",
      location: "Mumbai, India",
      achievements: [
        "Propelled customer acquisition by 25% through segment prioritization in carbon credit market",
        "Reduced verification cycle time by 40% through ESG-aligned onboarding workflows",
        "Mapped regulatory landscape across 12 emerging markets for carbon pricing opportunities",
      ],
    },
    {
      id: "soul-ai",
      company: "Soul AI",
      role: "Data Analyst",
      duration: "October 2024 - December 2024",
      location: "Remote",
      achievements: [
        "Optimized LLM outputs using RLHF, engineering 200+ prompts for coherence and factuality",
        "Analyzed mechanics of LLM fine-tuning and alignment challenges",
      ],
    },
    {
      id: "awe-funds",
      company: "AWE Funds",
      role: "Investment Analyst",
      duration: "August 2024 - October 2024",
      location: "Gurugram, India",
      achievements: [
        "Conducted financial modeling for ₹5-10Cr investments across supply chain decarbonization and medical devices",
        "Led due diligence on 3 companies and structured feedback for pre-seed founders",
      ],
    },
  ],

  projects: [
    {
      id: "cab-aggregator",
      title: "Cab Hailing Aggregation Platform",
      description: "Building a Skyscanner-style cab hailing aggregation platform for the Indian market. Integrating multiple cab service APIs with LLM-powered automation.",
      technologies: ["Python", "LLMs", "API Integration", "Product Development"],
      metrics: "INR 500K grant secured | IDEAS Level 2",
      link: null,
    },
    {
      id: "inventory-model",
      title: "Real-time Inventory Health Model",
      description: "Built SQL-based inventory optimization system with 30-day rolling forecasts, anomaly detection, and automated reorder triggers for mCaffeine.",
      technologies: ["SQL", "Data Analytics", "Forecasting", "Automation"],
      metrics: "Improved inventory turns 2.8x → 4.2x | ₹40+ Cr savings",
      link: null,
    },
    {
      id: "logistics-optimization",
      title: "Logistics Network Redesign",
      description: "Remapped fulfillment flows across 8 regional hubs using pincode-level demand clustering for optimized last-mile delivery routing.",
      technologies: ["Data Analysis", "Operations Research", "Python"],
      metrics: "Delivery time 3.8 → 2.6 days | ₹175K cost savings",
      link: null,
    },
    {
      id: "market-entry",
      title: "Medical Device Market Entry Strategy",
      description: "Quantified market opportunity and built 4-pillar GTM strategy for therapeutic device market entry, de-risking $2.5M capital allocation.",
      technologies: ["Market Research", "Financial Modeling", "Strategy"],
      metrics: "$28M whitespace identified | 120+ man-hours saved",
      link: null,
    },
  ],

  skills: {
    "Analytics & Data": ["Python", "SQL", "Machine Learning", "Data Visualization", "Statistical Analysis", "Forecasting"],
    "Strategy & Business": ["Financial Modeling", "Market Research", "GTM Strategy", "Due Diligence", "Unit Economics"],
    "Product & Operations": ["Product Development", "Process Optimization", "Supply Chain", "Stakeholder Management"],
    "Tools & Platforms": ["LLMs", "API Integration", "RLHF", "ESG Frameworks"],
  },

  education: [
    {
      institution: "Indian Institute of Technology, Bombay",
      degree: "Bachelor of Technology",
      field: "Energy Science & Engineering",
      duration: "October 2022 - May 2026",
    },
    {
      institution: "Christ Church Boys' Senior Secondary School",
      degree: "High School Diploma",
      field: "Information Technology",
      duration: "2007 - 2021",
    },
  ],

  certifications: [
    "McKinsey Forward Program",
    "Supervised Machine Learning: Regression and Classification",
    "Advanced Learning Algorithms",
    "Introduction to Data Science in Python",
    "Python Data Structures",
  ],
};
