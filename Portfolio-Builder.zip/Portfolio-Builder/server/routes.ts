import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";

const contactSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  message: z.string().min(10),
});

interface ContactMessage {
  id: string;
  name: string;
  email: string;
  message: string;
  createdAt: Date;
}

const messages: ContactMessage[] = [];

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/contact", async (req, res) => {
    try {
      const data = contactSchema.parse(req.body);
      
      const newMessage: ContactMessage = {
        id: crypto.randomUUID(),
        name: data.name,
        email: data.email,
        message: data.message,
        createdAt: new Date(),
      };
      
      messages.push(newMessage);
      
      console.log("New contact message received:", {
        name: newMessage.name,
        email: newMessage.email,
        messagePreview: newMessage.message.substring(0, 50) + "...",
      });
      
      res.json({ success: true, message: "Message received successfully" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid form data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to process message" });
      }
    }
  });

  app.get("/api/messages", async (_req, res) => {
    res.json(messages);
  });

  return httpServer;
}
